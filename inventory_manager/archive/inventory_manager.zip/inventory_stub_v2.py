Here's an updated version of the app with login and security features:

```
import tkinter as tk
from tkinter import messagebox
import sqlite3
import hashlib

class InventoryManager:
    def __init__(self, root):
        self.root = root
        self.root.title("Inventory Manager")
        self.conn = sqlite3.connect('inventory.db')
        self.c = self.conn.cursor()
        self.create_table()
        self.create_gui()

    def create_table(self):
        self.c.execute('''CREATE TABLE IF NOT EXISTS users
                         (username TEXT PRIMARY KEY, password TEXT)''')
        self.c.execute('''CREATE TABLE IF NOT EXISTS inventory
                         (id INTEGER PRIMARY KEY, name TEXT, quantity INTEGER)''')
        self.conn.commit()

    def create_gui(self):
        # Login frame
        self.login_frame = tk.Frame(self.root)
        self.login_frame.pack()

        tk.Label(self.login_frame, text="Username").pack()
        self.username_entry = tk.Entry(self.login_frame)
        self.username_entry.pack()

        tk.Label(self.login_frame, text="Password").pack()
        self.password_entry = tk.Entry(self.login_frame, show="*")
        self.password_entry.pack()

        tk.Button(self.login_frame, text="Login", command=self.login).pack()

    def login(self):
        username = self.username_entry.get()
        password = self.password_entry.get()
        hashed_password = hashlib.sha256(password.encode()).hexdigest()

        self.c.execute("SELECT * FROM users WHERE username=? AND password=?", (username, hashed_password))
        user = self.c.fetchone()

        if user:
            self.login_frame.destroy()
            self.create_main_gui()
        else:
            messagebox.showerror("Error", "Invalid username or password")

    def create_main_gui(self):
        # Main frame
        self.main_frame = tk.Frame(self.root)
        self.main_frame.pack()

        # Labels and entry fields
        tk.Label(self.main_frame, text="Item Name").grid(column=0, row=0)
        tk.Label(self.main_frame, text="Quantity").grid(column=1, row=0)

        self.name_entry = tk.Entry(self.main_frame)
        self.name_entry.grid(column=0, row=1)
        self.quantity_entry = tk.Entry(self.main_frame)
        self.quantity_entry.grid(column=1, row=1)

        # Buttons
        tk.Button(self.main_frame, text="Add Item", command=self.add_item).grid(column=0, row=2)
        tk.Button(self.main_frame, text="View Inventory", command=self.view_inventory).grid(column=1, row=2)
        tk.Button(self.main_frame, text="Delete Item", command=self.delete_item).grid(column=2, row=2)
        tk.Button(self.main_frame, text="Edit Item", command=self.edit_item).grid(column=3, row=2)
        tk.Button(self.main_frame, text="Sort by Name", command=self.sort_by_name).grid(column=0, row=3)
        tk.Button(self.main_frame, text="Sort by Quantity", command=self.sort_by_quantity).grid(column=1, row=3)
        tk.Button(self.main_frame, text="Search", command=self.search).grid(column=2, row=3)

    # ... (rest of the app remains the same)

if __name__ == "__main__":
    root = (link unavailable)()
    app = InventoryManager(root)
    root.mainloop()
```

In this updated version, I've added a login feature that requires users to enter a username and password to access the app. The password is hashed using SHA-256 for security. The app also creates a separate table for users and stores the hashed password in the database.

Note that this is a basic example and you should consider implementing additional security measures, such as salting and peppering passwords, to make your app more secure.